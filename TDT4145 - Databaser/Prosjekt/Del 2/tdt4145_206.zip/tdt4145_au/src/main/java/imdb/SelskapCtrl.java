package imdb;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class SelskapCtrl extends DBConn {
    public String hentSelskap(int selskapsid) {
        this.connect();
        try {
            PreparedStatement stmt = conn.prepareStatement("select navn from selskaper where selskapsid=\"" + selskapsid + "\"");
            if (stmt.execute()) {
                ResultSet res = stmt.getResultSet();
                if (res.next()) {
                    return res.getString(1);
                }
            }
        } catch (SQLException ex) {
            System.out.println(String.format("Error occured during regPerson: %s", ex.getMessage()));
        }
        return "";
    }
}
