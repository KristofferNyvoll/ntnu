package imdb;

import java.sql.*;
import java.util.ArrayList;

class PersonCtrl extends DBConn {
    public boolean regPerson(int personid, String navn, String fodselsdato, String nasjonalitet) {
        this.connect();
        try {
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO person VALUES (?, ?, ?, ?)");
            stmt.setInt(1, personid);
            stmt.setString(2, navn);
            stmt.setDate(3, Date.valueOf(fodselsdato));
            stmt.setString(4, nasjonalitet);

            return stmt.executeUpdate() != 0;
        } catch (SQLException ex) {
            System.out.println(String.format("Error occured during regPerson: %s", ex.getMessage()));
            return false;
        }
    }

    public int hentPersonId(String navn) {
        this.connect();
        try {
            String query = String.format("SELECT personid FROM person WHERE navn=\"%s\"", navn);
            PreparedStatement stmt = conn.prepareStatement(query);
            if (stmt.execute()) {
                ResultSet res = stmt.getResultSet();
                if (res.next()) {
                    return res.getInt(1);
                }
            }
        } catch (SQLException ex) {
            System.out.println(String.format("Error occured during hente personer: %s",
                    ex.getMessage()));
        }
        return -1;
    }

    public String hentPersonNavn(int personid) {
        this.connect();
        try {
            String query = String.format("SELECT navn FROM person WHERE personid=\"%s\"", personid);
            PreparedStatement stmt = conn.prepareStatement(query);
            if (stmt.execute()) {
                ResultSet res = stmt.getResultSet();
                if (res.next()) {
                    return res.getString(1);
                }
            }
        } catch (SQLException ex) {
            System.out.println(String.format("Error occured during hente personer: %s",
                    ex.getMessage()));
        }
        return "";
    }


    public ArrayList<String> hentSkuespillerRoller(int personid) {
        this.connect();
        ArrayList<String> roller = new ArrayList<>();
        try {
            PreparedStatement stmt = conn.prepareStatement("select rolle from skuespillerforfilm natural join person where personid=\"" + personid + "\"");
            if (stmt.execute()) {
                ResultSet res = stmt.getResultSet();
                while (res.next()) {
                    roller.add(res.getString(1));
                }
            }
        } catch (SQLException ex) {
            System.out.println(String.format("Error occured during regPerson: %s", ex.getMessage()));
        }
        return roller;
    }

    public ArrayList<String> hentSkuespillerOpptredelse(int personid) {
        this.connect();
        ArrayList<String> filmer = new ArrayList<>();
        try {
            PreparedStatement stmt = conn.prepareStatement("SELECT tittel FROM skuespillerforfilm NATURAL JOIN film WHERE personid=" + personid);
            if (stmt.execute()) {
                ResultSet res = stmt.getResultSet();
                while (res.next()) {
                    filmer.add(res.getString(1));
                }
            }
        } catch (SQLException ex) {
            System.out.println(String.format("Error occured during regPerson: %s", ex.getMessage()));
        }
        return filmer;
    }
}
