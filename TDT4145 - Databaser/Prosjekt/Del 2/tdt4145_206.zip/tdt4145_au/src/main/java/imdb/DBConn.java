package imdb;

import java.sql.*;
import java.util.Properties;

public class DBConn {
    protected Connection conn;

    public DBConn() {
    }

    public void connect() {
        try {
            conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1/akvo_imdb", "akvo", "fire123");
        } catch (Exception e) {
            throw new RuntimeException("Unable to connect man", e);
        }
    }

    public int getLatestId(String table) {
        this.connect();
        try {
            String query = String.format("SELECT MAX(%sid) from %s",table,table);
            System.out.println(query);
            PreparedStatement maxidStmt = conn.prepareStatement(query);
            int nextid = 1;
            if (maxidStmt.execute()) {
                ResultSet res = maxidStmt.getResultSet();
                System.out.println(res);
                if (res.next()) {
                    nextid = res.getInt(1) + 1;
                } else {
                    nextid = 1;
                }
            }
            return nextid;
        } catch (SQLException ex) {
            System.out.println(String.format("Error occured during regPerson: %s", ex.getMessage()));
            return 1;
        }
    }

}

