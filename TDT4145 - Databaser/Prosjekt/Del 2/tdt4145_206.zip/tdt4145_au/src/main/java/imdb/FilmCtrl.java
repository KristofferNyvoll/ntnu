package imdb;

import java.sql.*;
import java.util.ArrayList;

public class FilmCtrl extends DBConn {


    public boolean regFilm(int filmid, String tittel, int utgivelsear, String lanseringsdato,
                           String storyline, String lengde, String lagetfor, int lydsporid, int produsentid) {
        try {
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO film VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            stmt.setInt(1, filmid);
            stmt.setString(2, tittel);
            stmt.setInt(3, utgivelsear);
            stmt.setDate(4, Date.valueOf(lanseringsdato));
            stmt.setString(5, storyline);
            stmt.setTime(6, Time.valueOf(lengde));
            stmt.setString(7, lagetfor);
            stmt.setInt(8, lydsporid);
            stmt.setInt(9, produsentid);

            return stmt.executeUpdate() != 0;
        } catch (SQLException ex) {
            System.out.println(String.format("Error occured during regPerson: %s", ex.getMessage()));
            return false;
        }

    }



    public boolean regSkuespiller(int personid, int filmid, String rolle) {
        this.connect();
        try {
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO skuespillerforfilm VALUES(?,?,?)");
            stmt.setInt(1, personid);
            stmt.setInt(2, filmid);
            stmt.setString(3, rolle);
            return stmt.executeUpdate() != 0;
        } catch (SQLException ex) {
            System.out.println(String.format("Error occured during regPerson: %s", ex.getMessage()));
            return false;


        }
    }

    public boolean regRelation(int id1, int id2, String table) {
        this.connect();
        try {
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO " + table + " VALUES(?,?)");
            stmt.setInt(1, id1);
            stmt.setInt(2, id2);
            return stmt.executeUpdate() != 0;
        } catch (SQLException ex) {
            System.out.println(String.format("Error occured during regPerson: %s", ex.getMessage()));
            return false;
        }
    }

}
