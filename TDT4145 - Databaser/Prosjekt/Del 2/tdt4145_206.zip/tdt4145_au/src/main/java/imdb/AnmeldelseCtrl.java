package imdb;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Time;

public class AnmeldelseCtrl extends DBConn {
    public boolean regAnmeldese(int rating, String text, int filmid, int brukerid) {
        this.connect();
        try {
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO anmeldelse VALUES (?, ?, ?, ?)");
            stmt.setInt(1, rating);
            stmt.setString(2, text);
            stmt.setInt(3, filmid);
            stmt.setInt(4, brukerid);
            return stmt.executeUpdate() != 0;
        } catch (SQLException ex) {
            System.out.println(String.format("Error occured during regPerson: %s", ex.getMessage()));
            return false;
        }

    }
}
