package imdb;

import java.sql.PreparedStatement;
import java.sql.SQLException;

public class LydsporCtrl extends DBConn{
    public boolean regLydspor(int lydsporid, String albumnavn) {
        this.connect();
        try {
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO lydspor VALUES (?, ?)");
            stmt.setInt(1, lydsporid);
            stmt.setString(2, albumnavn);
            return stmt.executeUpdate() != 0;
        } catch (SQLException ex) {
            System.out.println(String.format("Error occured during regPerson: %s", ex.getMessage()));
            return false;
        }
    }

}
