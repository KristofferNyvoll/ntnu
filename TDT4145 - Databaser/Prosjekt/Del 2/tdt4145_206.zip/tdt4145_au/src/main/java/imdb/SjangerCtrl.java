package imdb;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class SjangerCtrl extends DBConn {
    public ArrayList<Integer> hentSelskapProdusertMestSjanger(int sjangerid) {
        ArrayList<Integer> result = new ArrayList<>();
        this.connect();
        try {
            PreparedStatement stmt = conn.prepareStatement(
                    "select produsentid, COUNT(produsentid) as value from sjangerifilm natural join sjanger " +
                            "natural join film where sjangerid=\"" + sjangerid + "\" GROUP BY produsentid ORDER BY value DESC LIMIT 1;");
            if (stmt.execute()) {
                ResultSet res = stmt.getResultSet();
                if (res.next()) {
                    result.add(res.getInt(1));
                    result.add(res.getInt(2));
                }
                return result;
            }
        } catch (SQLException ex) {
            System.out.println(String.format("Error occured during regPerson: %s", ex.getMessage()));
        }
        return null;
    }

    public String hentSjanger(int sjangerid) {
        this.connect();
        try {
            PreparedStatement stmt = conn.prepareStatement("select navn from sjanger where sjangerid=\"" + sjangerid + "\"");
            if (stmt.execute()) {
                ResultSet res = stmt.getResultSet();
                if (res.next()) {
                    return res.getString(1);
                }
            }
        } catch (SQLException ex) {
            System.out.println(String.format("Error occured during regPerson: %s", ex.getMessage()));
        }
        return "";
    }
}
